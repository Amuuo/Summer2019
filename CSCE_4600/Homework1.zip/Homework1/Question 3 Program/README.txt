compile question3.c with gcc and run ./generate_stats.sh
